
function Ej1 () {
    let nombre,edad, profesion;
    nombre = prompt("Cual es tu nombre?");

    edad = prompt("Cuantos años tienes?");

    profesion = prompt("Cual es tu profesion?");

    document.getElementById("ejer1").innerHTML = nombre + ": " + edad + " años. Profesion: " + profesion
    return
}


function Ej2 () {
    
    let n;
    n = prompt("Introduce un numero entero");
    
    if (n%2 != 0){
        document.getElementById("ejer2").innerHTML = "El numero es Impar"
    } else {
        document.getElementById("ejer2").innerHTML = "El numero es Par"
    }
    return
}



function Ej3 () {
    let tabla;
    tabla = "<section>";

    for (i=1; i<=10; i++){
        tabla +="<table border '1'> ";
    for (j=1; j<=10; j++){
        tabla += "<tr><td>"+i+" x "+j+" = "+(i*j)+"<br>"+"</tr></td>";
    }
        tabla += "</table><br>";
    }
        tabla += "</section>";
    document.getElementById("ejer3").innerHTML = tabla;
    return
}

function Ej4 () {
    let n1, n2, operador, operacion, resp;
    n1 = prompt("Escribe el número");
    n2 = prompt("Escribe el número");
    operador = prompt("Escribe símbolo del operador (+ - * /)");

    //IF
    if (operador =="+"){
        operacion = parseInt(n1) + parseInt(n2); 
        resp = n1+" "+operador+" "+n2+" = "+operacion;
    }
    else if(operador=="-"){
        operacion = n1 - n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
    }
    else if(operador==""){
        operacion = n1 * n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
    }
    else if(operador=="/"){
        operacion = n1 / n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
    }
    else{
        resp = "Operador no válido";
    }

    //SWITCH
    switch (operador){
        case "+":  operacion = parseInt(n1) + parseInt(n2); 
        resp = n1+" "+operador+" "+n2+" = "+operacion;
        break;

        case "-": operacion = n1 - n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
        break;

        case "": operacion = n1 * n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
        break;

        case "/":operacion = n1 / n2;
        resp = n1+" "+operador+" "+n2+" = "+operacion;
        break;

        default: resp = "Operador no válido";
        break;
    }

    document.getElementById("ejer4").innerHTML = resp;


    return
}

function Ej5 () {

    let n1, n2,mayor;
    n1 = prompt("Escribe el número");
    n2 = prompt("Escribe el número");


    if (n1>n2){
        document.getElementById("ejer5").innerHTML = "El mayor es el "+n1;
    }
    else{
        document.getElementById("ejer5").innerHTML = "El mayor es el "+n2;
    }

    return
}

function Ej6 () {

    let n1, ans=1;
    n1 = prompt("Escribe el número que se desee calcular el vectorial");

    for (i=n1; i>=1; i--){
        ans = ans * i;
    }
    document.getElementById("ejer6").innerHTML = "El factorial de "+n1+" es: "+ans;
    return
}

function Ej7 () {
    let n;

   
    do {
        n = prompt("Introduce un numero, el numero correcto es el que me ha dicho mi quinto primo");
    } while (n != 11);

    document.getElementById("ejer7").innerHTML = "Numero adivinado";

    return
}

function Ej8 () {
    let piramide="";
   n1 = prompt("Escribe el largo de la piramide");
 
   for (i=1; i<=n1; i++){
       for(j=1; j<=i; j++){
           piramide = piramide+i;
       }
       piramide = piramide+"<br>";
   }
   document.getElementById("ejer8").innerHTML = piramide;
   return
}

function Ej9 () {

    let nom = "";

    nom = prompt("Introduce un nombre");

    if (nom == "C3PO" || nom == "R2" || nom == "Vader" || nom == "Luck"){
        document.getElementById("ejer9").innerHTML = nom + "Es un personaje de Star Wars!";
    } else {
        document.getElementById("ejer9").innerHTML = nom + " no es un pj de las pelis que me gustan D:";
    }

    return
}

function Ej10 () {
    let nombre, edad, dia, precio = 12.5, iva=(12.5*1.21), total=iva, d1, d2, mensaje;
    nombre = prompt("Cual es tu nombre?");
    edad = prompt("Que edad tienes?");
    dia = prompt("Dia para viajar");

    if ((edad >= 18 && edad <= 26)|| edad >60){
        total = iva * 0.85;
        d1=true;
    }

    if (dia=="miercoles" || dia=="viernes"){
        total = total * 0.95;
        d2=true;
    }
    resumen = "Querido cliente "+nombre+"<br>"+ "Precio sin IVA "+precio+"<br>"+"Precio con IVA "+iva+"<br>";

    if (d1 = true){
        resumen = resumen+"Tiene un descuento por su edad del 15%"+"<br>";
    }
    if (d2 = true){
        resumen = resumen+"Tiene un descuento por viajar el dia "+dia+"<br>";
    }
    resumen = resumen+"Total: "+ total; 
    document.getElementById("ejer10").innerHTML = resumen;

    return
}

function Ej11 () {

    let n = "";
    let sino = true;
    
    do{
        sino = true;
        n = prompt("Introduce un numero entero");
        
        if (isNaN(n)){
            
            sino = false;
        } else {
            document.getElementById("ejer11").innerHTML = "El numero introducido tiene " + n.length + " cifras.";
        }
    } while (sino == false);
    
    return
}