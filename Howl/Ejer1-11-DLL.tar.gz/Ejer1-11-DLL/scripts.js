/*
let edad;
edad = prompt("que edad tienes?", 0);

alert("Tienes " + edad + " años.");
*/

/*
let nombre,edad;
nombre = prompt("Cual es tu nombre?");

edad = prompt("Cuantos años tienes?");

if (edad >= 18){
    document.getElementById("parOne").innerHTML = nombre + ": " + edad + " años. Eres mayor de edad."
} else{
    document.getElementById("parOne").innerHTML = nombre + ": " + edad + " años. Eres menor de edad."
};
*/
/*
for (let i = 0; i < 4; i++){
    alert(i);
}
*/

/*
let i = 2;
while (i != 0){
    alert(i);
    i = i - 1;
}
*/

/*
let clave = "e621", intent = "", n = 3;
var bool = false;

while ((clave != intent) && (n != 0)){
    intent = prompt("Introduce el codigo. Le quedan " + n + " intentos.");
    n = n - 1;
}

if (clave == intent){
    alert("Bienvenido al juego, Howler");
} else {
    alert("Quien es usted? Que? Ovidaste la contraseña... IMPOSIBLE");
}
*/

/*
let m=2;
do {
  alert(m);
  m = m + 2;
} while (m<=10);
*/

function pares () {
    
    return
}